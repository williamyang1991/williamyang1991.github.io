*************************************************************************************************
*************************************************************************************************
Human-drawn facial sketches in
Deep Plastic Surgery: Robust and Controllable Image Editing with Human-Drawn Sketches
ECCV 2020
*************************************************************************************************
*************************************************************************************************

Contents:

1. sketches: Collected 30 human-drawn facial sketches 
2. BicycleGAN: BicycleGAN results 
3. pix2pixHD: pix2pixHD results
4. our-G: results (I_{gen}) by our sketch refinement network G
5. our-F: results (I_{out}) by pretrained edge-based model F